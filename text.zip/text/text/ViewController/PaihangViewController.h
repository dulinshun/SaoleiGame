//
//  PaihangViewController.h
//  text
//
//  Created by hanlu on 16/8/4.
//  Copyright © 2016年 吴迪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaihangViewController : UIViewController

@property (nonatomic,assign) NSInteger difficulty;

@property (nonatomic,assign) NSInteger randomNum;

@end
