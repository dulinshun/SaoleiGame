//
//  ViewController.h
//  text
//
//  Created by hanlu on 16/7/30.
//  Copyright © 2016年 吴迪. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SaoleiChessView;
@interface SaoleiViewController : UIViewController

- (void)buttonDidClicked:(SaoleiChessView *)sender;


@end

